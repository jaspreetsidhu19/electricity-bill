//
//  ElectricityBillViewController.swift
//  ElectricityBill
//
//  Created by MacStudent on 2018-08-09.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class ElectricityBillViewController: UIViewController {
    var totalBill : ElectricityBill!
    @IBOutlet weak var customrId: UITextField!
    @IBOutlet weak var customrNm: UITextField!
   @IBOutlet weak var unitConsume: UITextField!
    @IBOutlet weak var gender: UISegmentedControl!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func btnSave(_ sender: Any) {
        
        totalBill = ElectricityBill(customerID: Int(customrId.text!), customername: customrNm.text!, gender: Gender.MALE, unitconsumed: Int(unitConsume.text!), totalbillamount: 0)
        //var DisplayViewController:DisplayViewController?
// DisplayViewController?.onUserAction( totalBill )
         let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let displayViewController = storyBoard.instantiateViewController(withIdentifier: "displayVC") as! DisplayViewController
        self.present(displayViewController, animated: true, completion: nil)
    
    }
    func setTotal(totalBill: Double) {
        print("A = \(totalBill)")
        //   lblTotalBill.isHidden = false
        // billDate.text = "Total Bill: $\(totalBill)"
    }
    override  func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let destVC = segue.destination as? DisplayViewController {
            print("\(totalBill)")
           // destVC.totalBill = totalBill
            destVC.delegate = self as! Topassdata
            
        }
        
    }
    }
   


