//
//  DisplayViewController.swift
//  ElectricityBill
//
//  Created by MacStudent on 2018-08-10.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

protocol Topassdata {
     func setTotal(totalBill: Double)
}

class DisplayViewController: UIViewController {
    
    @IBOutlet weak var customrId: UILabel!
    @IBOutlet weak var customrNm: UILabel!
    @IBOutlet weak var unit: UILabel!
    @IBOutlet weak var billtotal: UILabel!
    var totalBill : ElectricityBill!
   var delegate: Topassdata?
    override func viewDidLoad() {
        super.viewDidLoad()
       if let bill = totalBill
        {
           print(bill.customername!)
           TotalBillAmount()
            
      //  self.customrId.text = totalBill.customerID
       self.customrNm.text = totalBill.customername
           // self.unit.text = String(totalBill.unitconsumed)
           // self.gender.text = electricitybill.gender?.rawValue
       self.billtotal.text = String(totalBill.totalbillamount!)
        }
        
        
    
        // billtotal.t!ext = String(totalBill.totalBill(totalUnit: totalBill.totalUnit))*/
       
        

        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
   private func TotalBillAmount()
    {
        var totalBill1 = 0.0
        
        if(totalBill?.unitconsumed)! <= 100
        {
            totalBill1 = Double((totalBill?.unitconsumed)!) * 0.75
        }else if (totalBill?.unitconsumed)! <= 250
        {
            totalBill1 = 75 + (Double((totalBill?.unitconsumed)!) - 100) * 1.25
        }else if (totalBill?.unitconsumed)! <= 450
        {
            totalBill1 = 262.2 + (Double((totalBill?.unitconsumed)!) - 250) * 1.75
        }else
        {
            totalBill1 = 612.5 + (Double((totalBill?.unitconsumed)!) - 450) * 2.25
        }
        totalBill.totalbillamount = totalBill1
        print(totalBill)
        print(totalBill.totalbillamount)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
